import discord
from discord.utils import get
from discord.ext import commands, tasks
import time
from datetime import datetime, timedelta
client = commands.Bot(command_prefix="!")

@client.event
async def on_ready():
    print("STATUS DZIAŁA")
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name ="serwer Avexa Club"))

@client.command()
@commands.has_permissions(administrator = True)
async def sandra(ctx):

    embed=discord.Embed(title="Jak przejść weryfikacje?", color=0x00fffb,timestamp=datetime.utcnow())
    embed.add_field(name="\u200b", value="**Aby zweryfikować się wyślij wiadomość ```!verify```**", inline=False)
    embed.add_field(name="\u200b", value="**Gdy wysytąpią jakiekolwiek problemy z weryfikacją zgłoś się do moderatora bądź administratora**", inline=False)
    await ctx.send(embed=embed)


@client.event
async def on_message(message):
    channel = (828011225292079124)
    if message.channel.id == channel and message.content != "!verify":
        await message.delete()
        embed1=discord.Embed(title="Błąd", color=0xff0000,timestamp=datetime.utcnow())
        embed1.add_field(name="\u200b", value="**Użyj komendy !verify aby się zweryfikować! **", inline=False)
        embed1.set_thumbnail(url = "https://emoji.gg/assets/emoji/1326_cross.png")
        await message.author.send(embed=embed1)

    await client.process_commands(message)

@client.command()
async def verify(ctx):
    channel = (828011225292079124)
    if ctx.channel.id == channel:
        embed1=discord.Embed(title="Weryfikacja", color=0x00fffb,timestamp=datetime.utcnow())
        embed1.add_field(name="\u200b", value="**Zostałeś/aś zweryfikowany/a!**", inline=False)
        embed1.set_thumbnail(url = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/White_check_mark_in_dark_green_rounded_square.svg/1024px-White_check_mark_in_dark_green_rounded_square.svg.png")
        embed1.set_footer(text = f"{ctx.author}", icon_url = ctx.author.avatar_url)
        verifyrole = (discord.utils.get(ctx.guild.roles, name = "brak weryfikacji"))
        await ctx.author.remove_roles(verifyrole)
        await ctx.author.send(embed=embed1)
        await ctx.channel.purge(limit=1)
        await ctx.send("Zweryfikowano pomyślnie")







client.run("ODI4NjYwMDc4NTAzNzg4NjE0.YGsz1g.Y3r8w7nj7snzFsEMskjBfWxri6Y")

